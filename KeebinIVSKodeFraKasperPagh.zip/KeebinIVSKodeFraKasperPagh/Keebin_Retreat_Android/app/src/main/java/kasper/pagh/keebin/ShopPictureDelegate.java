package kasper.pagh.keebin;

import java.util.List;

import entity.BrandPicture;
import entity.ShopPicture;

/**
 * Created by kaspe on 08-03-2017.
 */

public interface ShopPictureDelegate
{
        public void sendShopPic(List<ShopPicture> bmList);
}
