package kasper.pagh.keebin;

/**
 * Created by kaspe on 14-05-2017.
 */

public interface OrderChangeListener
{
    public void updateList(int index);
}
