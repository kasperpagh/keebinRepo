package kasper.pagh.keebin;

/**
 * Created by kaspe on 2017-02-15.
 */

public interface DBListener
{
    public void DBReady();
}
