package kasper.pagh.keebin;

/**
 * Created by kaspe on 2016-10-27.
 */

public interface AsyncResponse
{
    void processFinished(String output);
}
